# GODOG FIGHT

This is an implementation of a dog fight game in Godot 3.2.2  
## Importent note:
If you want to use the trail renderer in your project simply copy the file `TrailRender.gd` from the `TrailRenderScriptClass` folder.  
By simply saving it in your project you will get a new node called `TrailRenderer` which is a standalone version of the trail renderer showed on the tutorial... trail renderer :-)
